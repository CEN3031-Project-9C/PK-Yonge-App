'use strict';

// Configuring the Articles module
angular.module('test_portal').run(['Menus',
  function (Menus) {

  }
]);
